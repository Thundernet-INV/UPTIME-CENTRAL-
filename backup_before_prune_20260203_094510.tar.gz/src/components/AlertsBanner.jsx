import React from "react";
/** AlertsBanner (stub): no renderiza nada. Mantiene compat sin romper el UI. */
export default function AlertsBanner(){ return null; }
