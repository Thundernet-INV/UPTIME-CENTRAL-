import React from "react";
export default function Cards({ counts, status, onSetStatus }) {
  const { up=0, down=0, total=0, avgMs=null } = counts ?? {};
  const Box = ({ title, value, color, active, onClick, subtitle }) => (
    <button type="button" className={`k-card k-card--summary is-clickable ${active ? "is-active" : ""}`}
            style={{ borderLeftColor: color }} onClick={onClick}>
      <div className="k-card__title">{title}</div>
      <div className="k-card__content"><span className="k-metric">{value}</span>{subtitle ? <span className="k-label" style={{marginLeft:8}}>{subtitle}</span> : null}</div>
    </button>
  );
  return (
    <div className="k-cards">
      <Box title="UP"    value={up}   color="#16a34a" active={status==="up"}   onClick={()=>onSetStatus(status==="up"?"all":"up")} subtitle="monitores" />
      <Box title="DOWN"  value={down} color="#dc2626" active={status==="down"} onClick={()=>onSetStatus(status==="down"?"all":"down")} subtitle="monitores" />
      <Box title="Total" value={total} color="#3b82f6" active={status==="all"} onClick={()=>onSetStatus("all")} subtitle="monitores" />
      <div className="k-card k-card--summary" style={{ borderLeftColor: "#6366f1" }}>
        <div className="k-card__title">Prom (ms)</div>
        <div className="k-card__content"><span className="k-metric">{avgMs ?? "—"}</span></div>
      </div>
    </div>
  );
}
