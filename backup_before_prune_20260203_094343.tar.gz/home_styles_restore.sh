#!/bin/sh
set -eu

ROOT="/home/thunder/kuma-dashboard-clean/kuma-ui"
SG="$ROOT/src/components/ServiceGrid.jsx"
MT="$ROOT/src/components/MonitorsTable.jsx"

ts=$(date +%Y%m%d_%H%M%S)
[ -f "$SG" ] && cp "$SG" "$SG.bak_styles_$ts" || true
[ -f "$MT" ] && cp "$MT" "$MT.bak_styles_$ts" || true

echo "== 1) ServiceGrid.jsx (Home GRID por instancia) con clases dinámicas =="
cat > "$SG" <<'JSX'
import React, { useEffect, useMemo, useState } from "react";
import History from "../historyEngine.js";
import Sparkline from "./Sparkline.jsx";

/**
 * HOME (GRID) por INSTANCIA con estilo dinámico:
 * - Usa clases 'service-card' / 'monitor-card' y 'status-badge badge--up/down'
 * - Tendencia (promedio sede 15 min) con Sparkline
 * - Métricas: UP/DOWN/TOTAL y Prom (ms)
 */
export default function ServiceGrid({
  monitorsAll = [],
  hiddenSet = new Set(),
  onOpen, // navegar a sede
}) {
  // Agrupar por instancia excluyendo ocultos por (instancia,monitor)
  const grouped = useMemo(() => {
    const map = new Map();
    for (const m of monitorsAll) {
      const key = JSON.stringify({ i: m.instance, n: m.info?.monitor_name });
      if (hiddenSet.has(key)) continue;
      const arr = map.get(m.instance) || [];
      arr.push(m);
      map.set(m.instance, arr);
    }
    return map;
  }, [monitorsAll, hiddenSet]);

  const instances = useMemo(() => Array.from(grouped.keys()).sort(), [grouped]);

  // Series por instancia (promedio 15 min para sparkline)
  const [seriesMap, setSeriesMap] = useState(new Map());
  const [tick, setTick] = useState(0);

  useEffect(() => {
    const t = setInterval(() => setTick(Date.now()), 10000);
    return () => clearInterval(t);
  }, []);

  useEffect(() => {
    let alive = true;
    (async () => {
      try {
        const pairs = await Promise.all(
          instances.map(async (inst) => {
            const arr = await History.getAvgSeriesByInstance(inst, 15*60*1000);
            return [inst, Array.isArray(arr) ? arr : []];
          })
        );
        if (!alive) return;
        setSeriesMap(new Map(pairs));
      } catch {
        if (!alive) return;
        setSeriesMap(new Map());
      }
    })();
    return () => { alive = false; };
  }, [instances.length, tick]);

  function metricsFor(inst) {
    const arr = grouped.get(inst) || [];
    const up    = arr.filter(m => m.latest?.status === 1).length;
    const down  = arr.filter(m => m.latest?.status === 0).length;
    const total = arr.length;
    const rts   = arr.map(m => m.latest?.responseTime).filter(v => typeof v === 'number');
    const avgMs = rts.length ? Math.round(rts.reduce((a,b)=>a+b,0)/rts.length) : null;
    const uptime = total ? Math.round((up/total)*100) : null;
    const statusBadge = down > 0 ? "badge--down" : "badge--up";
    return { up, down, total, avgMs, uptime, statusBadge };
  }

  return (
    <div className="services-grid">
      {instances.map((inst) => {
        const s = seriesMap.get(inst) || [];
        const m = metricsFor(inst);

        return (
          <div key={inst} className="service-card">
            {/* Header de card (usa layout y badge por clases existentes) */}
            <div className="service-card__head">
              {/* (Opcional) icono: lo dejamos vacío para no romper estilos */}
              <div className="service-card__texts">
                <div className="service-card__title">{inst}</div>
                <div className="service-card__subtitle">
                  {m.up} UP · {m.down} DOWN · {m.total} servicios
                  {m.avgMs != null ? ` · Prom ${m.avgMs} ms` : ""}
                </div>
              </div>
              <div className={`service-card__badge status-badge ${m.statusBadge}`}>
                {m.down > 0 ? "DOWN" : "UP"}
              </div>
            </div>

            {/* Sparkline de promedio de sede */}
            <div className="service-card__foot">
              <div className="service-card__sparkline">
                <Sparkline
                  points={s}
                  width={220}
                  height={40}
                  color="#3b82f6"
                />
              </div>
            </div>

            {/* Uptime + botón Ver sede (mantiene estilo textual, sin inline invasivo) */}
            <div style={{display:"flex", alignItems:"center", justifyContent:"space-between", marginTop:6}}>
              <div style={{ fontSize:12.5, color:"#374151" }}>
                Uptime: {m.uptime != null ? `${m.uptime}%` : "—"}
              </div>
              <button className="k-btn k-btn--ghost" onClick={() => onOpen?.(inst)}>
                Ver sede
              </button>
            </div>
          </div>
        );
      })}
    </div>
  );
}
JSX

echo "== 2) MonitorsTable.jsx (Home TABLA por instancia) con badges/clases =="
cat > "$MT" <<'JSX'
import React, { useEffect, useMemo, useState } from "react";
import History from "../historyEngine.js";
import Sparkline from "./Sparkline.jsx";

/**
 * HOME (TABLA) por INSTANCIA:
 * - Instancia | UP | DOWN | Total | Prom (ms) | Tendencia | Uptime | Acciones
 * - Badges/clases para look & feel dinámico
 */
export default function MonitorsTable({
  monitors = [],
  hiddenSet = new Set(),
  onOpen,  // abrir sede
}) {
  // Agrupar por instancia excluyendo ocultos
  const grouped = useMemo(() => {
    const map = new Map();
    for (const m of monitors) {
      const key = JSON.stringify({ i: m.instance, n: m.info?.monitor_name });
      if (hiddenSet.has(key)) continue;
      const arr = map.get(m.instance) || [];
      arr.push(m);
      map.set(m.instance, arr);
    }
    return map;
  }, [monitors, hiddenSet]);

  const instances = useMemo(() => Array.from(grouped.keys()).sort(), [grouped]);

  // Series promedio por instancia (15 min)
  const [seriesMap, setSeriesMap] = useState(new Map());
  const [tick, setTick] = useState(0);
  useEffect(() => {
    const t = setInterval(() => setTick(Date.now()), 10000);
    return () => clearInterval(t);
  }, []);
  useEffect(() => {
    let alive = true;
    (async () => {
      try {
        const pairs = await Promise.all(
          instances.map(async (inst) => {
            const arr = await History.getAvgSeriesByInstance(inst, 15*60*1000);
            return [inst, Array.isArray(arr) ? arr : []];
          })
        );
        if (!alive) return;
        setSeriesMap(new Map(pairs));
      } catch {
        if (!alive) return;
        setSeriesMap(new Map());
      }
    })();
    return () => { alive = false; };
  }, [instances.length, tick]);

  function metricsFor(inst) {
    const arr = grouped.get(inst) || [];
    const up    = arr.filter(m => m.latest?.status === 1).length;
    const down  = arr.filter(m => m.latest?.status === 0).length;
    const total = arr.length;
    const rts   = arr.map(m => m.latest?.responseTime).filter(v => typeof v === 'number');
    const avgMs = rts.length ? Math.round(rts.reduce((a,b)=>a+b,0)/rts.length) : null;
    const uptime = total ? Math.round((up/total)*100) : null;
    const statusBadge = down > 0 ? "badge--down" : "badge--up";
    return { up, down, total, avgMs, uptime, statusBadge };
  }

  return (
    <div style={{ overflowX: "auto" }}>
      <table className="k-table">
        <thead>
          <tr>
            <th>Instancia</th>
            <th>Estado</th>
            <th>UP</th>
            <th>DOWN</th>
            <th>Total</th>
            <th>Prom (ms)</th>
            <th>Tendencia</th>
            <th>Uptime</th>
            <th>Acciones</th>
          </tr>
        </thead>
        <tbody>
          {instances.map((inst) => {
            const m = metricsFor(inst);
            const s = seriesMap.get(inst) || [];
            return (
              <tr key={inst}>
                <td style={{ fontWeight:600, color:"#111827" }}>{inst}</td>
                <td>
                  <span className={`status-badge ${m.statusBadge}`}>
                    {m.down > 0 ? "DOWN" : "UP"}
                  </span>
                </td>
                <td style={{ color:"#16a34a", fontWeight:600 }}>{m.up}</td>
                <td style={{ color:"#dc2626", fontWeight:600 }}>{m.down}</td>
                <td>{m.total}</td>
                <td>{m.avgMs!=null ? `${m.avgMs} ms` : "—"}</td>
                <td style={{ minWidth:160 }}>
                  <Sparkline
                    points={s}
                    width={160}
                    height={32}
                    color="#3b82f6"
                  />
                </td>
                <td>{m.uptime!=null ? `${m.uptime}%` : "—"}</td>
                <td>
                  <button className="k-btn k-btn--ghost" onClick={() => onOpen?.(inst)}>
                    Ver sede
                  </button>
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}
JSX

echo "== 3) Build & Deploy =="
cd "$ROOT"
npm run build
rsync -av --delete dist/ /var/www/uptime8081/dist/
nginx -t && systemctl reload nginx
echo "✓ Home con estilo dinámico restaurado (clases/badges) y métricas por instancia."
